<template>
	<view>
	<view class='swiper'>
	    <mosowe-swiper
	        :lists="text"
	        :touchable="true"
	        vertical
	        swiperType="text"
	        textKey="title"
	        :height="80"
	        />
	</view>
	</view>
</template>

<script>
	export default {
		data() {
			
			text: [
			    {
			        title: '车静安寺客户嘎哈放框架傲胜'
			    },
			    {
			        title: '任务的确认吧是发是对方是个地方个三四个'
			    },
			    {
			        title: '接口环境看是否度萨芬，吧撒打发看了会焦点时发卡机撒打发'
			    }
			]

		
		},
		methods: {
			
		}
	}
</script>

<style>
.swiper{
    height: 80rpx;
    font-size: 28rpx;
    line-height: 80rpx;
    padding: 0 30rpx;
    box-sizing: border-box;
    background-color: #fe8252;
    color: #fff;
    }

</style>
