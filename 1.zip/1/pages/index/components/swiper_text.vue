<template>
	<view>
			<scroll-view class="notice-content">
				<swiper class="swiper" :autoplay="true" :interval="switchTime*1000" :duration="1500" :circular="true" :vertical="true">
					<swiper-item v-for="(t, index) in list" :key="index" class="notice-content-item">
						<view class="swiper-item">
							<text class="notice-content-item-text" :style="'color: '+color+';'">
								{{t}}
							</text>
						</view>
					</swiper-item>
				</swiper>
			</scroll-view>
			<view class="btn" @click="more">
				<text class="gd">查看更多</text>
				<image src='../../../static/图标/ckgd.png'></image>
			</view>
	</view>
</template>

<script>
	export default {
		props:{
			list: {
				type: Array,
				default: ['暂无未读消息','你好']
			}, 
			color: {
				type: String,
				default: '#de8c17'
			},
			bgColor: {
				type: String,
				default: '#dcdcdc'
			},
			switchTime: {
				type: Number,
				default: 3
			},
		},
		data() {
			return {
		
			}
		},
	methods:{
		more(){
			{
					uni.navigateTo({
						url: '../../pages/more/more',
						 fail (error) {
						        console.log(error)
						    }
					})
				}
		}
		
	}
	}
</script>

<style>
	.swiper{
		height: 60upx!important;
	}
	.notice-box{
		width: 100%; 
		height: 60upx; 
		padding: 0 10upx; 
		overflow: hidden; 
		margin: 20upx 0; 
		display: flex; 
		justify-content: flex-start;
	}
	.notice-content{
		width: calc(100% - 220upx); 
		position: relative; 
		font-size: 14px;
	}
	.notice-content-item{
		width: 100%; 
		height: 60upx; 
		text-align: left; 
		line-height: 60upx;
	}
	.notice-content-item-text{
		display: block; 
		white-space: nowrap; 
		text-overflow: ellipsis; 
		overflow: hidden;
	}
	
	@keyframes anotice {
		 0%  {transform: translateY(100%);}
	    30%  {transform: translateY(0);}
	    70%  {transform: translateY(0);}
	   100%  {transform: translateY(-100%);}
	}
	image{
		width: 30px;
		height: 15px;
		float: right;
	}
	.gd{
		font-weight: 400;
		font-size: 12px;
		float: right;
		color: #F0AD4E;
	}
</style>
