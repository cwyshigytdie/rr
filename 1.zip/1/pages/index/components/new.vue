<template>
	<view>
		<view class="new">
			<text style="font-weight: 500;">最近上新</text>	
		</view>
		<view class="jj">
			<image class="img" src="https://tse2-mm.cn.bing.net/th/id/OIP-C.t0r0AAd22InQ6iOJ6h9cMgHaHZ?w=193&h=192&c=7&r=0&o=5&dpr=2&pid=1.7"></image>
		</view>
	</view>
</template>

<script>
</script>

<style>
	.img{
		width: 750rpx;
		height: 350rpx;
	}
	.new{
		background-color: #F0AD4E;
	}
	.txt{
		background-color: #C8C7CC;
	}
</style>
