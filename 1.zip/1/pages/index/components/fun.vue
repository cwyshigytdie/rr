<template>
 <view class="nar">
  <view class="nar-a">
   <image @click="dc" src="../../../static/图标/dc.png"></image>
   <text>线上点餐</text>
	 </navigator> 
  </view>
  <view class="nar-a">
   <image src="../../../static/图标/kd.png"></image>
   <text>快递代取</text>
  </view>
  <view class="nar-a">
   <image src="../../../static/图标/supermarket.png"></image>
   <text>超市代购</text>
  </view>
  <view class="nar-a">
   <image src="../../../static/图标/forum.png"></image>
   <text>论坛贴吧</text>
  </view>
 </view>
 
</template>

<script>
	export default {
		
		data() {
			return {
	
			}
		},
		onLoad() {
	
		},
		methods: {
			dc(){
					uni.navigateTo({
						url: '../../pages/Online_ordering/Online_ordering',
						 fail (error) {
						        console.log(error)
						    }
					})
				}
			}
	
		}
	
</script>

<style>
 .nar{
  display: flex;
  width: 750rpx;
  height: 200rpx;
  background-color: #F1F1F1;
 }
 .nar-a{
  margin: 15px 16px;
  width: 60px;
  height: 60px;
  font-size: 14px;
 } 
 image{
  width: 50px;
  height: 50px;
 }
</style>