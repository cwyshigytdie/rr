<template>
	<view class="content">
		<view class="sousuo">
		<Search class="ss"></Search>
		</view>
		<Swiper></Swiper>
		<fun></fun>
		<New></New>
		<Swiper_Text></Swiper_Text>
	</view>
</template>
<script>
	import Search from './components/search.vue'
	import Swiper from './components/swiper.vue'
	import Fun from'./components/fun.vue'
	import New from'./components/new.vue'
	import Swiper_Text from './components/swiper_text.vue'
	export default {
		components: {
			Search,
			Swiper,
			Fun,
			New,
			Swiper_Text
		},
		data() {
			return {

			}
		},
		onLoad() {

		},
		methods:{
			// tz(){
			// 	uni.navigateTo({
			// 		url: "./swiper",
			// 		fail (error) {
			// 		       console.log(error)
			// 		   }
			// 	})
			// }
			}
		}
</script>

<style>
	/* .img{
		width: 60px;
		height: 60px;
		float: right;
	} */
	.sousuo{
		background-color: #F0AD4E;
	}
	.ss{
		background-color: #FFFFFF;
	}
	.fun{
		width: 100px;
		height: 100px;
	}
	.nar{
	 display: flex;
	 width: 750rpx;
	 height: 200rpx;
	 background-color: #F1F1F1;
	}
	.nar-a{
	 margin: 15px 16px;
	 width: 60px;
	 height: 60px;
	 font-size: 14px;
	} 
	image{
	 width: 50px;
	 height: 50px;
	}
</style>
