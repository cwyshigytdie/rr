<template>
	<view class="home">
		<!--circular用来设置循环轮播   indicator-dots设置下面小圆点用来点击 -->
		<swiper :indicator-dots="true" :autoplay="true" :interval="4000" :duration="400" :circular="true"
		indicator-color="rgba(255, 255, 255)"
		indicator-active-color="#F1F1F1">
			<swiper-item v-for="item in swipers">
				<image :src="item"></image>
			</swiper-item>
		</swiper>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				swipers:[
					'https://tse3-mm.cn.bing.net/th/id/OIP-C.56jhAfotHRp0WOYtRQN8hQHaE8?w=290&h=193&c=7&r=0&o=5&dpr=2&pid=1.7',
					'https://tse1-mm.cn.bing.net/th/id/OIP-C.UR3O0AhhSU3zuEuDwKQ_jQHaE7?w=291&h=194&c=7&r=0&o=5&dpr=2&pid=1.7',
					'https://tse4-mm.cn.bing.net/th/id/OIP-C.R-t-MY4CJwXOHyWAFk1L0AHaE8?w=273&h=182&c=7&r=0&o=5&dpr=2&pid=1.7',
				]
			}
		},
	}
</script>

<!-- 开启scss -->
<style lang="scss">
	.home{
		// width:750px ;
		// height: 370px;
		swiper{
			width: 750rpx;
			height: 370rpx;
			image{
				width: 100%;
				height: 100%;
			}
		}
	}
</style>

