<template>
	<view>
		<Server></Server>
<Swiper1></Swiper1>
	</view>
</template>

<script>
	import Server from '../index/components/search.vue'
	import Swiper1 from './swiper1.vue'
	import Store from'./store.vue'
	export default {
		components:{
			Server,
			Swiper1
		},
		data() {
			return {
			}
		},
		methods: {
			
		}
	}
</script>

<style>

</style>
