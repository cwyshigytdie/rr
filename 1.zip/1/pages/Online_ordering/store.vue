<template>
	<view>
			<view class="list-coment">
			<block v-for="(item,index) in List" :key="index">
				<!-- <view class="list_image" @click="btninsu(item.id)"> -->
					<view class="list_image">
					<image :src="item.img" mode="aspectFill"></image>
						<view class="text">{{txt}}</view>
						<!-- </view> -->
					</view>
			
				
			</block>
			</view>
				</view>
</template>
<script>
	export default {
		props: {
			insurance: Array,
			List:[{
			img:['https://tse1-mm.cn.bing.net/th/id/OIP-C.QPH1IBosDYBqaU3O6wV3YAHaEo?w=309&h=193&c=7&r=0&o=5&dpr=2&pid=1.7',],
			tet:['1']
			
			},
			
			
				
			]
			
		},
		
		data() {
			return {
				
				
	
			}
		},
		onLoad() {
	
		},
		methods: {
			}
	
		}
</script>

<style>
</style>
