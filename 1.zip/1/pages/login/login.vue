<template>
	<view class="">
	
		<van-dialog id="van-dialog" />
	<van-image class="logo logo-image" width="50" height="50" src="https://img.yzcdn.cn/vant/cat.jpeg" />
	
		<p class="logo logo-font">安洛外卖ss</p>	
		
			<uni-popup ref="popup" background-color="#fff" >
				<view class="popup-content">
					<view><text class="text1">安洛外卖</text></view>
					<view class="text-2"><text class="text2">获取您的手机号</text></view>
					<view class="text-3"><text class="text3">您可以完成注册和登录操作</text></view>
					 <view class="text-4"></view>
					 <view class="text-5">155****7420 <text class="text5">微信绑定号码</text> <img class="text-img"src="../../static/duihao.png" alt=""></view>
					 <view class="text-4"></view>
					<view class="text-6"><text class="text6">使用其他手机号码</text></view>
					<view class="text-7">
						<van-row>
						  <van-col span="7" offset="5"><van-button class="text-button-1" @click="openss()" type="default">拒绝</van-button></van-col>
						
						  <van-col span="8" offset="3"><van-button class="text-button-2"  @click="opensss()" type="primary">允许</van-button></van-col>
						</van-row>
						
					                
					</view>
					</view>
			</uni-popup>
			<uni-popup ref="popups" background-color="#fff" >
				<view class="popup-content">
					<view><text class="text1">安洛外卖</text></view>
					<view class="text-2"><text class="text2">获取您的头像和昵称</text></view>
					 <view class="text-4"></view>
					 <view class="text-5"><img style="width: 50px;height: 50px;" src="https://img.yzcdn.cn/vant/cat.jpeg" alt="">	<text class="text5">微信头像</text> <img class="text-img-1"src="../../static/duihao.png" alt=""></view>
					 <view class="text-4"></view>
					 <view class="text-5"><text>昵称</text>	<text class="text5">微信昵称</text> <img class="text-img-2"src="../../static/duihao.png" alt=""></view>
					 <view class="text-4"></view>
					<view class="text-7">
						<van-row>
						  <van-col span="7" offset="5"><van-button class="text-button-1"  type="default">拒绝</van-button></van-col>
						
						  <van-col span="8" offset="3"><van-button class="text-button-2" type="primary">允许</van-button></van-col>
						</van-row>
						
					                
					</view>
					</view>
			</uni-popup>
		
		<button   @click="opens()"    class="logo logos-button" size="normal">微信一键登录</button>

<label class="logo-radio"><radio @click="los()" value="r1" :checked="dd" />登录代表您已经同意 <span class="logo-font-co">隐私协议</span></label>


<van-loading v-if="loade" class="jiazai" size="24px">加载中...</van-loading>
<van-loading v-if="loades" class="jiazai" size="24px">登录中...</van-loading>
	</view> 
	
</template> 
  
<script>
	
	import Dialog from '@/wxcomponents/dist/dialog/dialog';
	export default{
		components:{
	
		},
		data() { 
			return {
			dd:true,
			 show: false,
			type:'bottom',
			 loade:false,
		loades:false,
		user:'',
		useris:false,
		lout:true,
		showge:true,
	
			}
		},
		onLoad(){
		
						},
						
						
methods:{
	// opensss(){
		
	// 	this.$refs.popup.close()
	// 	let p =	setTimeout(()=>{
	// 			this.loade =true
				 
	// 		},0)
	// 		let pp = setTimeout(()=>{
	// 			this.loade=false
	// 		},500)
	// 		let ppp=setTimeout(()=>{
	// 			this.$refs.popups.open('bottom')
	// 		},400)
	// },
	// openss(){
	
	// 	Dialog.alert({
	// 		title:'提醒',
	// 		  message: '需要通过授权才能继续',
	// 		}).then(() => {
		
	// 		});
	// 		this.$refs.popup.close()
	// },
	opens(){
	
	let thes = this
	if(thes.dd==false){
		Dialog.alert({
			  message: '请阅读并勾选底部协议',
			}).then(() => {
		
			}); 
	}else if(thes.dd==true){
		setTimeout(()=>{
					  this.loade =true
		},0)
		setTimeout(()=>{
					  this.loade =false 
		},500)
									let that = this;
									uni.login({
													provider: 'weixin',
													success: function(loginRes) {
														console.log(loginRes)
														if(loginRes){
															 if(that.dd==true){
																			uni.showModal({
																				title:'提示',
																				content:'需要获取微信头像和昵称',
																				success(res) {
																					if(res.confirm){
																					uni.getUserProfile({
																						desc:'ss',
																						success:function(res) {
																						    that.user=	JSON.stringify(res.userInfo) 
																						console.log(that.user)
																						let ss=uni.setStorage({
																							key: 'use',
																							data: that.user ,
																						});
																						let sss=uni.setStorage({
																							key: 'uses',
																							data: that.useris ,
																						});
																						let ssss=uni.setStorage({
																							key: 'usess',
																							data: that.lout ,
																						});
																						let sssss=uni.setStorage({
																							key: 'usesss',
																							data: that.showge,
																						});
																						
																							uni.reLaunch({
																								url: '../../pages/my/my?user='+that.user,
																								// success(res) {
																								// 	res.eventChannel.emit('acceptDataFromOpenerPage', {date:thes.user})
																								// }
																							});
																							uni.showToast({
																								title:'登录成功'
																							})
																						},
																						
																						fail() {
																							uni.showToast({
																								title:'获取失败',
																								icon:'error'
																							})
																						}
																					})
																				
																					}
																				}
																			})											
															}
															
														}
													
													}
												});
	}	 
	},  

	los(){
		if(this.dd==true){
			this.dd=false
		} else if(this.dd==false){
			this.dd=true
		}
	
	}
}
	}
	
	
	 
</script>

<style>
	.text-img-2{
		width: 20px;
		height: 20px;
		position: absolute;
		right: 10%;
		margin-top: 8px;
	}
	.text-img-1{
		width: 20px;
		height: 20px;
		position: absolute;
		right: 10%;
		margin-top: 10px;
	}
	.jiazai{
		display: flex;
		justify-content: center;
		align-items: center;
		margin-top: 20px;
	}
	.text-img{
		width: 20px;
		height: 20px;
margin-top: 3px;
		position: absolute;
		right: 10%;
		
	}
	.text1{
		font-size: 15px;
		font-weight: bold;
		margin-left: 50px;
	}
	.text2{
		font-size: 15px;
		font-weight: bold;
	}
	.text3{
		font-size: 12px;
		color: black;
	}
	.text-2{
		margin-top: 10px;
	}
	.text-3{
		margin-top: 3px;
	}.text-4{
		display: flex;
		justify-content: center;
		align-items: center;
		margin-top: 3px;
		border: 0.2px solid lightgray;
		background-color: lightgray;
	}
	.text-5{
		margin-top: 20px;
	}
	.text5{
		margin-left: 5px;
		font-size: 13px;
		color:lightgray;
	}
	.text-6{
		margin-top: 20px;
	
	}
	.text6{
		font-size: 13px;
		font-weight: 300;
		color: #ffaa00;
	}.text-7{
		
		margin-top: 20px; 
	}.text-button-1{
		
	}
	.text-button-2{
		
	}
.popup-content{ 
	padding: 15px;
	height: 250px;
	background-color: #fff;
},
	.logo{
	display: flex;
	justify-content: center;
	align-items: center;
	},
	.logo-image{
		margin-top: 100px;
	}
	.logo-font{
		font-size: 18px;
		font-weight: bold;
	}
	.logos-button{
		display: flex;
		justify-content: center;
		align-items: center;
		width: 200px;
		margin-top: 100px;
		border-radius: 10px;
	}     
	.logo-radio{
		position: absolute;
		top: 90%;
		left:12%;
		transform:scale(0.6);
		

	}
	.logo-font-co{
		color: #ffaa00;
	}

</style>