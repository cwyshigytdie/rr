<template>
	
	<view class="stroe">
	
					
				
		           <view>
					   <uni-card class=""><uni-section title="基本示例" type="line">
					   <view><button  @click="showss()" class="button-sss" type="warn">
							  管理
							   </button>
							   <button  v-if="showi" @click="losss()"  class="button-sss" type="warn">
							   							  全选
							   							   </button>
														   <button v-if="showi" class="button-sss" type="warn">
														   							  删除
														   							   </button></view>
						   
							   							  
							   
							   </uni-section>
							   </uni-card>
				   </view>
		<uni-card  margin="2px" class="store_a" v-for="(item,index) in arr" :key="item.id">
			<view>
			<view class="picture">
				<image :src="item.src" ></image>
				 
			</view>
		  	<uni-rate class="sss" :size="15" :readonly="true"  :max="5"  v-model="value" @change="onChanges"/>
			<view class="store-b">
				<view>{{item.title}}</view>
				<view>{{item.introduction}}</view>
				<view v-if="shows">  <radio-group @change="radioChange">	<radio class="radio-s"     :value="item.id" color="red" :checked="item.dd" /></radio-group> 选择</view>
			</view>
		<view class="xian"></view>
			 
			</view>
			
		</uni-card>
	</view>
</template>

<script>
export default{
	data(){
		return{
			
			value: 2,
			values:1,
			dds:false,
			type:'bottom',
			shows:false,
			showi:false,
		current:0,
			arr:[ 
				{id:'1',src: 'http://t14.baidu.com/it/u=2564522853,4007573576&fm=224&app=112&f=JPEG?w=500&h=500',
				 title:'美味鲜水果店', introduction:'水果',dd:false},
				 {id:'2',src: 'http://t14.baidu.com/it/u=2564522853,4007573576&fm=224&app=112&f=JPEG?w=500&h=500',
				  title:'美味鲜水果店', introduction:'水果',dd:false},
				  {id:'3',src: 'http://t14.baidu.com/it/u=2564522853,4007573576&fm=224&app=112&f=JPEG?w=500&h=500',
				   title:'美味鲜水果店', introduction:'水果',dd:false},
				   {id:'4',src: 'http://t14.baidu.com/it/u=2564522853,4007573576&fm=224&app=112&f=JPEG?w=500&h=500',
				    title:'美味鲜水果店', introduction:'水果',dd:false},
					{id:'5',src: 'http://t14.baidu.com/it/u=2564522853,4007573576&fm=224&app=112&f=JPEG?w=500&h=500',
					 title:'美味鲜水果店', introduction:'水果',dd:false},
					 
					 {id:'6',src: 'http://t14.baidu.com/it/u=2564522853,4007573576&fm=224&app=112&f=JPEG?w=500&h=500',
					  title:'美味鲜水果店', introduction:'水果',dd:false},
				{id:'7',src: 'https://img2.baidu.com/it/u=35255866,1888809959&fm=253&fmt=auto&app=138&f=JPEG?w=600&h=400',
				 title:'coco奶茶店', introduction:'饮品',dd:false}
			]	
				
			
		}
	},
	methods:{
		// radioChange:function(evt){
		// 	   for (let i = 0; i < this.arr.length; i++) {
		// 	                if (this.arr[i].id === evt.detail.value) {
		// 						console.log(this.arr[i].dd)
								
		// 						// if( evt.detail.value==0){
									
		// 						// }
			              
			                   
		// 	                }
		// 	            }
		// },
		losss(){
				let than = this
			for(let i=0;i<=than.arr.length;i++){
						let ss=  than.arr
					 let sss =  ss[i];
					 
						
						 	 if( sss.dd==false){
											sss.dd=true
										} else if(sss.dd==true){
											sss.dd=false
										}
					 }
		},
	//  	losssw(){
	// 		let than = this
	// 		for(let i=0;i<=than.arr.length;i++){
	// 			let ss=  than.arr
	// 		 let sss =  ss[i];
	// 		  for(let a=0;a<=sss.id;a++){
				
	// 			 	 if( sss.id==1 &&sss.dd==false){
	// 								sss.dd=true
	// 							} else if(sss.id==1 && sss.dd==true){
	// 								sss.dd=false
	// 							}
	// 		  }
			 
		 
	// 			//
	// 		}
		
	// // 			
			
	// 	},
		showss(){
			if(this.shows==false && this.showi==false){
				this.shows=true
				this.showi=true
			} else if(this.shows==true && this.showi==true){
				this.shows=false
				this.showi=false
			}
			
		},
		onChange(e) {
					console.log('rate发生改变:' + JSON.stringify(e))
				},
				
				radioChange:function(evt){
					for (let i = 0; i < this.arr.length; i++) {
						  console.log(i)
					    if (this.arr[i].value === evt.detail.value) {
					        
						
					       
					    }
					}
					// let than =this
					// for(let i=0;i<=than.arr.length;i++){
					// 	let ss=  than.arr
						
					//  let sss =  ss[i];
					  
						
					// 	 	 if(sss.dd==false){
					// 						sss.dd=true
					// 					} else if(sss.dd==true){
					// 						sss.dd=false
					// 					}
					
					 
							 
					// 	//  	 if(  sss.dd==false){
					// 	// 					sss.dd=true
					// 	// 				} else if(sss.dd==true){
					// 	// 					sss.dd=false
					// 	// 				}
						
					// }
				
				}
	},
	
}
</script>

<style>
		
		
	.radio-s{
		
		transform:scale(0.8);
	}
	.button-ss{
		width: 50px;
		height: 50px;
	}
	.button-sss{
		width: 80px;
		height: 60px;
		display: inline;
		margin-right: 5px;
	}
	.xian{
		display: flex;
		justify-content: center;
		align-items: center;
		border: 0.5px solid gainsboro;
		width: 100%;
	}
.store{
	width: 100%;
	height: 220rpx;
	display: flex;
	flex-direction: column;
	margin-top: 3px;
	padding: 20rpx;
	
}
.store_a{
	float: left;
	margin: 8rpx;
	background-color: #ffffff;
		
	width: 95%;
}
.picture{
	margin: 8rpx;
	height: 200rpx;
	width: 260rpx;
	float: left;
}
image{
	height: 200rpx;
	width: 260rpx;
}
.store-b,.sss{
	float: left;
margin-left: 20px;
}
</style>