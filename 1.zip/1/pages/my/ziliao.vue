<template>
	
	<view class="Info">
		<uni-forms ref="form" style="margin-top: 10px;" :rules="rules" :modelValue="formData">
			<uni-forms-item class="input" label="姓名:" name="name">
				
				<uni-easyinput class="ss"type="text" v-model="formData.name" placeholder="请输入姓名" />
			</uni-forms-item>
			
			<uni-forms-item    name="value" label="性别：">
					<uni-data-checkbox v-model="formData.value"   :localdata="genders" />
			</uni-forms-item>
			
			<uni-forms-item  class="input"  name="phone" label="电话号码：">
			<uni-easyinput type="text" v-model="formData.phone" placeholder="请输入电话号码" />
			</uni-forms-item>
			<uni-forms-item  class="input"  name="ids" label="学号：">
			<uni-easyinput type="text" v-model="formData.ids" placeholder="请输入学号" />
			</uni-forms-item>
			<uni-forms-item  class="input"  name="xueyuan" label="所在学院：">
			<uni-easyinput type="text" v-model="formData.xueyuan" placeholder="请输入学院" />
			</uni-forms-item>
			<uni-forms-item  class="input"  name="classs" label="班级：">
			<uni-easyinput type="text" v-model="formData.classs" placeholder="请输入班级" />
			</uni-forms-item>
			<button @click="submit()">保存资料</button>
		</uni-forms>
	</view>

</template>

<script>
	export default{
		data(){
			return{	
				value: 0,
										genders: [{"value": 0,"text": "男"	},{"value": 1,"text": "女"}],
			formData: {
							name: 'LiMing',
							ids:'',
							xueyuan:'',
							classs:'',
							phone:''
						},
						rules: {
								value: {
													rules: [{
														required: true,
														errorMessage: '请选择性别',
													},]
												},
										name: {
											rules: [{
													required: true,
													errorMessage: '请输入姓名',
												},
												{
													minLength: 1,
													maxLength: 5,
													errorMessage: '姓名长度在 {minLength} 到 {maxLength} 个字',
												}
											]
										},
										xueyuan: {
											rules: [{
													required: true,
													errorMessage: '请输入学院',
												},
											]
										},
										classs: {
											rules: [{
													required: true,
													errorMessage: '请输入班级',
												},
											]
										},
										ids: {
											rules: [{
													required: true,
													errorMessage: '请输入学号',
												},
																			
											]
										},
										phone: {
											rules: [{
													required: true,
													errorMessage: '请输入电话号码',
												},
									
												{
												                                 format: 'number',
												                                 errorMessage: '手机号码只能输入数字'
												                             },
											]
										},
										
						}
			}
		
		},
		methods:{
			submit() {
						this.$refs.form.validate().then(res=>{
							console.log('表单数据信息：', res);
						}).catch(err =>{
							console.log('表单错误信息：', err);
						})
					}
			
		}
	}
</script>

<style>
	
	.Info {
	  width: 100%;
	  display: flex;
	  flex-direction: column;
	  align-items: center;
	  background-color: white;
	  margin-bottom: 20rpx;
	}
	.infoItem {
	  width: 90%;
	  display: flex;
	  align-items: center;
	  padding: 30rpx 10rpx 30rpx 10rpx;
	  border-bottom: 1rpx solid rgb(240, 240, 240);
	}
	.item-label {
	  width: 35%;
	  
	}
	button{
	  width: 375rpx;
	  height: 80rpx;
	  margin-top: 20rpx;
	  background-color: orange;
	}
	

</style>