
<template>
	<view class="Info">
		<uni-forms ref="form" style="margin-top: 10px;" :rules="rules" :modelValue="formData">
			<uni-forms-item class="input" label="账号:" name="ids">
				
				<uni-easyinput class="ss"type="text" v-model="formData.ids" placeholder="请输入账号" />
			</uni-forms-item>
		
			<uni-forms-item  class="input"  name="password" label="密码：">
			<uni-easyinput type="password" v-model="formData.password" placeholder="请输入密码 " />
			</uni-forms-item>
			
			<uni-forms-item  class="input"  name="dianname" label="店铺名：">
			<uni-easyinput type="text" v-model="formData.dianname" placeholder="请输入店铺名" />
			</uni-forms-item>
			、
			<uni-forms-item  class="input"  name="yyzz" label="所在学院：">
			<uni-easyinput type="text" v-model="formData.yyzz" placeholder="请输入学院" />
			</uni-forms-item>
			<uni-forms-item  class="input"  name="classs" label="班级：">
			<uni-easyinput type="text" v-model="formData.classs" placeholder="请输入班级" />
			</uni-forms-item>
			<button @click="open()">保存资料</button>
		</uni-forms>
	</view>
</template>

<script>
	export default{
		methods:{
			open(){
				uni.chooseImage({
					count: 6, //默认9
					sizeType: ['original', 'compressed'], //可以指定是原图还是压缩图，默认二者都有
					sourceType: ['album'], //从相册选择
					success: function (res) {
						console.log(JSON.stringify(res.tempFilePaths));
					}
				});
			}
		}
	}
</script>

<style>
</style>