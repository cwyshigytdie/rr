<template>
	<view class="">

					
			<uni-forms ref="form" :rules="rules" :modelValue="formData">
				<uni-forms-item class="input" label="收货地址:" name="address">
					
					<uni-easyinput class="ss"type="text" v-model="formData.address" placeholder="请输入收货地址" />
				</uni-forms-item>
				
				<uni-forms-item class="input"   name="name" label="联系人：">
				<uni-easyinput type="text" v-model="formData.name" placeholder="请输入姓名" />
				</uni-forms-item>
				
				<uni-forms-item  class="input"  name="phone" label="电话号码：">
				<uni-easyinput type="text" v-model="formData.phone" placeholder="请输入电话号码" />
				</uni-forms-item>
				<button @click="submit()">添加</button>
			</uni-forms>
			
			
		</view>
</template>

<script>
export default{
	data(){
		return{	
		formData: {
						name: 'LiMing',
	
						address:'',
						phone:''
					},
					rules: {
							
									name: {
										rules: [{
												required: true,
												errorMessage: '请输入姓名',
											},
											{
												minLength: 1,
												maxLength: 5,
												errorMessage: '姓名长度在 {minLength} 到 {maxLength} 个字',
											}
										]
									},
									address: {
										rules: [{
												required: true,
												errorMessage: '请输入收货地址',
											},
											{
												minLength: 1,
												maxLength: 20,
												errorMessage: '地址长度在 {minLength} 到 {maxLength} 个字',
											}
										]
									},
									phone: {
										rules: [{
												required: true,
												errorMessage: '请输入电话号码',
											},
								
											{
											                                 format: 'number',
											                                 errorMessage: '手机号码只能输入数字'
											                             },
										]
									},
									
					}
		}
	
	},
	methods:{
		submit() {
					this.$refs.form.validate().then(res=>{
						console.log('表单数据信息：', res);
					}).catch(err =>{
						console.log('表单错误信息：', err);
					})
				}
		
	}
}
	
</script>

<style>
	.input{
		display: flex;
		padding: 30rpx 10rpx 30rpx 10rpx;
		border-bottom: 1rpx solid rgb(240, 240, 240);
	
	}
	.ss{
		width: 300px;
		height: 300px;
	}
	button{
		margin-top: 60rpx;
		width: 600rpx;
		line-height: 100rpx;
		border-radius: 60rpx;
		 background-color: orange;
	}
</style>