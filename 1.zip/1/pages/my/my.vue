<template>
  <view class="wrapper">
    
	<view class="profile">
		<view><text style="font-size: 15px;font-weight: bold;display: flex;justify-content: center;align-items: center;">昵称: <text v-if="users.nickName!=unedfined">{{users.nickName}}</text></text></view>
		<view style="display: flex;justify-content: center;align-items: center;"> <img style="width: 50px; height: 50px;border-radius: 50px;" v-model="users" :src="users.avatarUrl" alt=""></view>
		<view>
			<van-row>
			  <van-col span="24">	<button v-if="usersis"    class="login"  @click="login()" color="#F0AD4E">登录/注册</button></van-col>
			</van-row>
			
		</view>
	</view>
    
    <view v-if="showge">
    <view class="count">
      <view class="cell" @click="shoucan()">  <text>收藏的店铺</text> </view>
     
      <view class="cell">  <text>我的足迹</text> </view>
    </view>
		<van-loading v-if="lodse" class="jiazai" size="24px">退出中...</van-loading>
		<van-loading v-if="loade" class="jiazai" size="24px">加载中...</van-loading>
    <!-- 我的订单 -->
    <view class="orders">
      <view class="title">我的订单</view>
      <view class="sorts">
        <text class="icon-bill">待付款</text>
        <text class="icon-car">待收货</text>
        <text class="icon-money">退款/退货</text>
        <text class="icon-list">全部订单</text>
      </view>
    </view>
	<view @click="sss()" class="personal data">
		学生接单入住
		<image class="more" src="../../static/more.png"></image>
	</view>
	<view @click="sssss()" class="personal data">
		商家入住
		<image class="more" src="../../static/more.png"></image>
	</view>
    <!-- 地址管理 -->
    <view @click="ssss()"  class="address icon-arrow">
      收货地址
	  <image class="more" src="../../static/more.png"></image>
    </view>
    <!-- 其它 -->
    <view class="extra">
      <view @click="makePhone" class="item icon-arrow">联系客服</view>
      <button open-type="feedback" class="item icon-arrow">意见反馈</button>
	   <button v-if="lout" @click="logout()" class="item icon-arrow item-sss">退出登录</button>
    </view>
</view>
  </view>
</template>

<script>
export default {
		
	
	data(){
		return{	
			users:{
				avatarUrl:'../../static/头像.png',
			},
		  usersis:true,
		  lodse:false,
		  lout:false,
		  loade:false,
		  showge:false,
		}
	
	},
	watch:{
			users(newVal, oldVal) {
				
				}
	},
  methods: {
	  shoucan(){
		  setTimeout(()=>{
		  			 this.loade=true
		  },0)
		  setTimeout(()=>{
		  			 this.loade=false
		  },500)
		  uni.navigateTo({
		  	url: '../../pages/my/shoucan'
		  });
	  },
	  sssss(){
		  setTimeout(()=>{
		  			 this.loade=true
		  },0)
		  setTimeout(()=>{
		  			 this.loade=false
		  },500)
		  uni.navigateTo({
		  	url: '../../pages/my/shanjia'
		  });
	  },
	  ssss(){
		  setTimeout(()=>{
		  			 this.loade=true
		  },0)
		  setTimeout(()=>{
		  			 this.loade=false
		  },500)
		  uni.navigateTo({
		  	url: '../../pages/my/shouhuo'
		  });
	  },
	 sss(){
		 setTimeout(()=>{
			 this.loade=true
		 },0)
		 setTimeout(()=>{
		 			 this.loade=false
		 },500)
		 uni.navigateTo({
		 	url: '../../pages/my/ziliao'
		 });
	 },
	  logout(){

	if(this.users=='' && this.users==null && this.users==undefined){
				 uni.showToast({
				   title:'操作失败'
				 })
	}else if(this.users)
	try{

		uni.clearStorageSync();
			uni.removeStorageSync('uses');
			uni.removeStorageSync('usess');
			uni.removeStorageSync('usesss');
			uni.reLaunch({
				url: '../../pages/my/my'
			});
			let p =	setTimeout(()=>{
					this.lodse =true
					 
				},0)
				let pp = setTimeout(()=>{
					this.lodse=false
				},500)
				
		}catch(e){
			
		}
	setTimeout(()=>{
				uni.showToast({
				  title:'退出成功'
				})
	},700)
	  },
	 setData:function(obj){    
	 let that = this;    
	 let keys = [];    
	 let val,data;    
	 Object.keys(obj).forEach(function(key){    
	  keys = key.split('.');    
	  val = obj[key];    
	  data = that.$data;    
	  keys.forEach(function(key2,index){    
	      if(index+1 == keys.length){    
	          that.$set(data,key2,val);    
	      }else{    
	          if(!data[key2]){    
	             that.$set(data,key2,{});    
	          }    
	      }    
	      data = data[key2];    
	  })    
	 });    
	 }   ,
	login(){
		setTimeout(()=>{
					 this.loade=true
		},0)
		setTimeout(()=>{
					 this.loade=false
		},500)
	  		uni.redirectTo({
	  			url: '../../pages/login/login',
	  		})
	  	},
		onLoad: function (option) { //option为object类型，会序列化上个页面传递的参数
	 uni.getStorage({
		 key:'use',
		 success:(res)=> {
		 this.users = JSON.parse(res.data)
		 	
		 	
		 }
	 });
	 uni.getStorage({
	 		 key:'usess',
	 		 success:(res)=> {
	 		 this.lout = JSON.parse(res.data)
	 		 },
	 		 
	 });
	 uni.getStorage({
	 		 key:'uses',
	 		 success:(res)=> {
	 		 this.usersis =res.data
	 		 	
	 		 	
	 		 } 
	 });
	 uni.getStorage({
	 		 key:'usesss',
	 		 success:(res)=> {
	 		 this.showge =res.data
	 		 	
	 		 	
	 		 } 
	 });
		if(option.user==null && option.user=="" &&option.user==undefined){
			this.users = JSON.parse(option.user)
			
		}else if(option.user){
			
			this.users =   JSON.parse(option.user)
	
		}       
		
			},
			
    makePhone() {
      // 调用 API 拨打电话
      uni.makePhoneCall({
        phoneNumber: "10086",
      });
    },
  },
};
</script>

<style scoped lang="less">
	.login{
	 display: flex;
	 justify-content: center;
	 align-items: center;
	 margin-top: 10rpx;
	 background-color: #f4f4f4;
	 font-size: 30rpx;
	 width: 200rpx;
	 height: 80rpx;
	
	}
	.jiazai{
		display: flex;
		justify-content: center;
		align-items: center;
		
	}
.wrapper {
  position: absolute;
  top: 0;
  bottom: 0;

  width: 100%;
  background-color: #f4f4f4;
}
.profile {
  height: 375rpx;
  background-color: #F0AD4E;
}
.count {
  display: flex;
  margin: 0 20rpx;
  height: 100rpx;
  text-align: center;
  border-radius: 4rpx;
  background-color: #fff;

  position: relative;
  top: -27rpx;

  .cell {
    flex: 1;
    padding-top: 16rpx;
    font-size: 27rpx;
    color: #333;
  }

  text {
    display: block;
    font-size: 24rpx;
  }
}

.orders {
  margin: -17rpx 20rpx 0 20rpx;
  padding: 20rpx 0;
  background-color: #fff;
  border-radius: 4rpx;

  .title {
    padding-left: 20rpx;
    font-size: 30rpx;
    color: #333;
    padding-bottom: 20rpx;
    border-bottom: 1rpx solid #eee;
  }

  .sorts {
    padding-top: 30rpx;
    text-align: center;
    display: flex;
  }

  [class*="icon-"] {
    flex: 1;
    font-size: 24rpx;

    &::before {
      display: block;
      font-size: 48rpx;
      margin-bottom: 8rpx;
      color: #ea4451;
    }
  }
}
.personal {
  line-height: 1;
  background-color: #fff;
  font-size: 30rpx;
  padding: 25rpx 0 25rpx 20rpx;
  margin: 10rpx 20rpx;
  color: #333;
  border-radius: 4rpx;
}
.address {
  line-height: 1;
  background-color: #fff;
  font-size: 30rpx;
  padding: 25rpx 0 25rpx 20rpx;
  margin: 10rpx 20rpx;
  color: #333;
  border-radius: 4rpx;
}

.extra {
  margin: 0 20rpx;
  background-color: #fff;
  border-radius: 4rpx;

  .item {
    line-height: 1;
    padding: 25rpx 0 25rpx 20rpx;
    border-bottom: 1rpx solid #eee;
    font-size: 30rpx;
    color: #333;
  }

  button {
    text-align: left;
    background-color: #fff;

    &::after {
      border: none;
      border-radius: 0;
    }
  }
}

.icon-arrow {
  position: relative;

  &::before {
    position: absolute;
    top: 50%;
    right: 20rpx;
    transform: translateY(-50%);
  }
}
.more{
	width: 40rpx;
	height: 40rpx;
	float: right;
	margin-right: 10px;
}
.item-sss{
	display: flex;
	justify-content: center;
	align-items: center;
}
</style>
