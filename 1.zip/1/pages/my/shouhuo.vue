<template>
	<view class="add">
		<view style="margin-top: 30px;" class="add_former" v-for="(item,index) in arr" :key="index">
			<view>地址：{{item.address}}</view>
			<view style="margin-top: 10px;">姓名：{{item.name}}  电话：{{item.phone}}</view>
		</view>
		
		
		<view class="add_new" @click="goNew()">
			<view class="new">
				新增地址
			</view>
		</view>
	</view>
</template>

<script>
	export default{
		data(){
			 return {
			    arr: [
			      { address: '昆明市官渡区宝海创业园', name: '小猪猪',phone: 111111111 },
			      { address: '昆明市官渡区宝海创业园', name: 'hhh',phone: 222222222 },
				  { address: '昆明市官渡区宝海创业园', name: '嘤嘤嘤',phone: 4582185 },
				  { address: '昆明市官渡区宝海创业园', name: '略略略',phone: 95655221 }
			    ]
			  }
		},
		methods:{
			goNew(){
				uni.redirectTo({
					url:"../../pages/my/addshouhuo"
				})
			}
		}
	}
</script>

<style>
	.add_former{
		width: 750rpx;
		height: 100rpx;
		background-color: ghostwhite;
		margin: 5px;
	}
	.add_new{
		display: flex;
		justify-content: space-around;
		  width: 600rpx;
		  line-height: 100rpx;
		  position: absolute;
		  bottom: 30rpx;
		  left: 80rpx;
		  background-color: orange;
		  border-radius: 60rpx;

	}
	.new{
		display: flex;
		align-items: center;
		font-size: 40rpx;
		color: #ffffff;
	}
</style>